//
//  TestEntity+CoreDataClass.h
//  CacheTest
//
//  Created by Phillip Mills on 2020-01-12.
//  Copyright © 2020 Phillip Mills. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestEntity : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "TestEntity+CoreDataProperties.h"
