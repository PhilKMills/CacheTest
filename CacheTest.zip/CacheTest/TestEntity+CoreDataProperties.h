//
//  TestEntity+CoreDataProperties.h
//  CacheTest
//
//  Created by Phillip Mills on 2020-01-12.
//  Copyright © 2020 Phillip Mills. All rights reserved.
//
//

#import "TestEntity+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface TestEntity (CoreDataProperties)

+ (NSFetchRequest<TestEntity *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *ident;

@end

NS_ASSUME_NONNULL_END
