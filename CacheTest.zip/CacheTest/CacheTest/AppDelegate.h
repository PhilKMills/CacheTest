//
//  AppDelegate.h
//  CacheTest
//
//  Created by Phillip Mills on 2020-01-12.
//  Copyright © 2020 Phillip Mills. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

#define APP_DELEGATE ((AppDelegate *)([[UIApplication sharedApplication] delegate]))

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

- (void)saveContext;


@end

