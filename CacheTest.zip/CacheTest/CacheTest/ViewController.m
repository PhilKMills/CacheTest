//
//  ViewController.m
//  CacheTest
//
//  Created by Phillip Mills on 2020-01-12.
//  Copyright © 2020 Phillip Mills. All rights reserved.
//

#import "ViewController.h"

#import "AppDelegate.h"
#import "TestEntity+CoreDataProperties.h"
#import "TestEntity+CoreDataClass.h"

@interface ViewController ()
@property (nonatomic, strong) NSFetchedResultsController *results;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSManagedObjectContext *ctx = APP_DELEGATE.persistentContainer.viewContext;
    NSDate *date = [NSDate date];
    for (int i = 0; i < 3; i++) {
        NSString *str = [NSString stringWithFormat:@"%@ - %d", [date description], i];
        TestEntity *ent = [NSEntityDescription insertNewObjectForEntityForName:@"TestEntity" inManagedObjectContext:ctx];
        ent.ident = str;
    }
    [APP_DELEGATE saveContext];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self setupResultsController];
}

- (void)setupResultsController {
    NSError *error = nil;
    NSManagedObjectContext *ctx = APP_DELEGATE.persistentContainer.viewContext;
    
    // Create a fetch request and execute it directly
    NSFetchRequest *fetchRequest = [TestEntity fetchRequest];
    
    [fetchRequest setFetchBatchSize:20];
    
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"ident" ascending:YES];
    NSArray *sortDescriptors = @[sortDescriptor];
    
    [fetchRequest setSortDescriptors:sortDescriptors];
    NSArray *debugResults = [ctx executeFetchRequest:fetchRequest error:&error];
    NSLog(@"Count from context fetch: %lu", (unsigned long)debugResults.count);
    
    // Use the request to populate a NSFetchedResultsController
    NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc]
                                                             initWithFetchRequest:fetchRequest
                                                             managedObjectContext:ctx
                                                             sectionNameKeyPath:@"ident"
                                                             cacheName:@"Detail"];
    aFetchedResultsController.delegate = self;
    
    [aFetchedResultsController performFetch:&error];
    NSLog(@"Count from results controller fetch: %lu", (unsigned long)[[aFetchedResultsController fetchedObjects] count]);
    
    _results = aFetchedResultsController;
}

- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    // Allow cache changes
}

@end
