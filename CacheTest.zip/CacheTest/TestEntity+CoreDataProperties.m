//
//  TestEntity+CoreDataProperties.m
//  CacheTest
//
//  Created by Phillip Mills on 2020-01-12.
//  Copyright © 2020 Phillip Mills. All rights reserved.
//
//

#import "TestEntity+CoreDataProperties.h"

@implementation TestEntity (CoreDataProperties)

+ (NSFetchRequest<TestEntity *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"TestEntity"];
}

@dynamic ident;

@end
