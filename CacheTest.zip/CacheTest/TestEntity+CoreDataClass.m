//
//  TestEntity+CoreDataClass.m
//  CacheTest
//
//  Created by Phillip Mills on 2020-01-12.
//  Copyright © 2020 Phillip Mills. All rights reserved.
//
//

#import "TestEntity+CoreDataClass.h"

@implementation TestEntity

@end
